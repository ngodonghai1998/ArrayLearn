//Định nghĩa prototype SinhVien
function SinhVien () {
    this.maSinhVien = '';
    this.tenSinhVien = '';
    this.diemToan = '';
    this.diemLy ='';
    this.diemHoa = '';
    this.diemRenLuyen = '';
    this.email = '';
    this.soDienThoai = '';
    this.loaiSinhVien = '';
}