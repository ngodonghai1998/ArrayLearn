/* -------------  Cơ chế khai báo biến ------------------------- */

/*
    Phạm vi biến
    var: Hỗ trợ cơ chế hoisting, nên phạm vi biến là toàn cục
    let: Không hỗ trợ hoisting, khi khai báo biến trùng tên với nhau trên cùng 1 scope thì browser sẽ báo lỗi. Khi khai báo let ở các scope khác nhau thì giá trị sẽ phân biệt.
    const: Tương tự let tuy nhiên giá trị không được phép gán lại
    => Dùng let thay cho var khi khai báo biến trong es6
*/
let title = 'abc';
{
    let title = 'xyz';
    console.log(title); //???
};
console.log(title); //???
const DOMAIN = 'https://api.cybersoft.edu.vn';
{
    const DOMAIN = 'abc';
}

var arrButton = document.querySelectorAll('button');

for (let index = 0; index < arrButton.length; index++) {
    let btn = arrButton[index];
    btn.onclick = function () {
        alert(btn.innerHTML);
    }
}
// {
//     let index = 0;
//     let btn = arrButton[index];
//     btn.onclick = function () {
//         alert(btn.innerHTML);
//     }
// }
// {
//     let index = 1;
//     let btn = arrButton[index];
//     btn.onclick = function () {
//         alert(btn.innerHTML);
//     }
// }
// {
//     let index = 2;
//     let btn = arrButton[index];
//     btn.onclick = function () {
//         alert(btn.innerHTML);
//     }
// }

/* --------------------- Hàm ----------------------- */

//declaration function (hỗ trợ hoisting)
function tenHam() {
    console.log('tên hàm');
}
//expression function (không hỗ trợ hoisting)
var showMessage = function () {
    console.log('showMessage');
}

tenHam();
showMessage();


/*  ------------------ context (ngữ cảnh this) -----------------------------
    object: Trong object this sẽ là object 
    function: Trong function đối tượng nào thực thi phương thức thì this sẽ là đối tượng đó . Nói cách khác this trong function là function đó.
    default(mặc định): this là window (Khi ngữ cảnh chồng chéo nhau) - Nếu mở tính năng module của thẻ script thì sẽ báo lỗi
*/




console.log('chiều rộng', window.innerWidth);
console.log('tiêu đề web', window.document.title);
console.log('họ tên', window.hoTen);

var sinhVien = {
    ma: 1,
    ten: 'Huy',
    hienThiThongTin: function () {
        var hienThi = () => {
            console.log(this.ma);
            console.log(this.ten);
        }
        hienThi();
    }
}

sinhVien.hienThiThongTin();



function Product() {
    this.id = '';
    this.name = '';
    this.showInfo = function () {
        console.log('id', this.id);
        console.log('name', this.name);
    }
}
var prd1 = new Product();
prd1.id = 1;
prd1.name = 'Product A';
prd1.showInfo();
var prd2 = new Product();
prd2.id = 2;
prd2.name = 'Product B';
prd2.showInfo();


// ---------------- Arrow function --------------------------
/*
    Arrow function là cách khai báo hàm với cú pháp => 
    + Khai báo hàm ngắn gọn hơn
        + Đối với hàm chỉ có 1 tham số thì sẽ không cần () cho tham số. ví dụ: (title) => {}  tương đương title => {}
        + Đối với hàm chỉ có 1 lệnh return thì sẽ không cần ghi chữ return và {}. Ví dụ:  (a,b)=> {return a+b;} tương đương (a,b) => a + b
    + Loại bỏ ngữ cảnh (this)
    + Không dùng cho việc khai báo prototype và cũng không hỗ trợ hoisting
    => dùng cho mục đích khai báo hàm (hàm tìm số nguyên tố, hàm xử lý chức năng, hàm onclick, onchange, event ....);


*/
var showInfoProduct = () => {
    console.log('Hello cybersoft bc43');
    console.log(this);
}


var sayHello = (name) => {
    return 'hello' + name;
}

var sayHelloArrow = name => `hello ${name}`;
//Viết tắt của arrow 

var renderObject = (id,name) => ({
        id:id,
        name:name
})






/** -----Bài tập---- */

let arrColors = ['red', 'green', 'blue', 'pink', 'orange', 'black'];

let renderButton = () => {
    //Cách 1: Tạo ra các button = dom => append lên ui
    // for(let index = 0 ; index < arrColors.length;index++){
    //     let color = arrColors[index];
    //     //Tạo ra button
    //     let btn = document.createElement('button');
    //     btn.className = 'btn text-light mx-2';
    //     btn.style.background = color;
    //     btn.innerHTML = color;
    //     btn.onclick = function () {
    //         document.getElementById('home').style.color = color;
    //     }

    //     document.getElementById('colors').appendChild(btn);
    // }
    //Cách 2: 
    let outputHTML = ``;
    for (let index = 0; index < arrColors.length; index++) {
        //Mỗi lần duyệt lấy ra 1 màu từ mảng arrColor
        let color = arrColors[index];
        outputHTML += `
            <button class="btn text-white mx-2" style="background-color:${color};" onclick="changeColor('${color}')">${color}</button>
        `
    }
    //Hiển thị output lên giao diện
    document.getElementById('colors').innerHTML = outputHTML;

}
renderButton();

window.changeColor = (color) => {
    document.querySelector('#home').style.color = color;
}

//-------------------------- Deafault parameter values -------------------------------

var getUserInfo = (name="Mị",age = 18) => {
    if(age > 0 && age < 30) {
        console.log(`${name} còn trẻ ${name} muốn đi chơi !`);
    }
}

