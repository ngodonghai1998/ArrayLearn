
let arrProduct = [
    {id:1,name:'IPhone X',price:1000, type:'Phone'},
    {id:2,name:'IPhone XS',price:1250, type:'Phone'},
    {id:3,name:'IPhone XS MAX',price:1350, type:'Phone'},
    {id:4,name:'IPad pro 13',price:1050, type:'Tablet'},
    {id:5,name:'IPad pro max 13',price:1550, type:'Tablet'},
    {id:6,name:'Macbook m1',price:1250, type:'Laptop'},
    {id:7,name:'Macbook m2',price:1750, type:'Laptop'},
    {id:8,name:'Macbook m3',price:2350, type:'Laptop'}
]


//Yêu cầu: Từ mảng arrProduct lấy ra các sản phẩm có type là Phone
function getPhoneProduct () {
    let arrPhone = [];
    for(let prod of arrProduct) {
        if(prod.type === 'Phone') {
            arrPhone.push(prod);
        }
    }
    return arrPhone;
}
let res = getPhoneProduct();
console.log('res',res);

//.filter: là method của array dùng để lọc ra các object thỏa tiêu chí của arrow function. kết quả trả về là arr [], nếu không có phần tử nào khớp sẽ trả về arr rổng

let resPhone = arrProduct.filter(prod => prod.type === 'Phone');

console.log('resPhone',resPhone);
//Lấy ra các sản phẩm có giá từ 1250 trở lên
let resPhone1250 = arrProduct.filter(product => product.price >= 1250);
console.log('resPhone1250',resPhone1250);

//.find: là method của array dùng để lấy ra giá trị của 1 phần tử thỏa điều kiện. Nếu không có phần tử nào thỏa điều kiện arrow function thì trả về undefined. Thường dùng để lấy ra 1 phần tử để chỉnh sửa dữ liệu (sử dụng với trường định danh ví dụ như id)
let phoneId6 = arrProduct.find(prod => prod.id === 6); 
if(phoneId6){
    phoneId6.price += 200;
}
console.log('phoneId6',phoneId6);
//.findIndex: Tương tự find hàm findindex sẽ trả về vị trí nếu điều kiện hợp lệ, và trả về -1 nếu không tìm thấy.
//Yêu cầu xóa sản phẩm có id là 5
let indexDel = arrProduct.findIndex(prod => prod.id === 5);
if(indexDel !== -1){
    arrProduct.splice(indexDel,1);
    console.log('arrProduct',arrProduct);
}

// arrProduct = arrProduct.filter(prod => prod.id !== 6);

// console.log('arrProduct',arrProduct);

//Log ra các phần tử trong arrProduct

for (let prod of arrProduct){
    console.log(prod)
}


//.foreach(): Dùng để thực hiện các chức năng trên các phần tử trong mảng. Có thể dùng for in hoặc for of để sử dụng.
arrProduct.forEach((prod,index) => {
    console.log('index',index);
    console.log('prod',prod);
});
arrProduct.forEach((prod,index) => {
    console.log('index1',index);
    console.log('prod1',prod);
});

let colors = ['red','green','blue','pink'];

//.map(): Dùng để biến đổi mảng A => mảng B tương đương
let arrButton = colors.map((item,index) => {
    let btn = document.createElement('button');
    btn.innerHTML = item;
    btn.className = 'btn mx-2 border';
    btn.style.color = item;


    return btn;
});

console.log('arrButton',arrButton);

document.querySelector('#colors').append(...arrButton);


let arrBadge = colors.map((item,index) => {
    let tagBadge = document.createElement('span');
    tagBadge.innerHTML = item + ' ' + index;
    tagBadge.className = 'badge text-white mx-2';
    tagBadge.style.background = item;
    return tagBadge;
});

document.querySelector('#colors').append(...arrBadge);


//.reduce dùng để duyệt qua các phần tử của mảng tổng hợp thành 1 giá trị
//input arrColor => output:' <div class="card">red</div> <div class="card">green</div>"
// let colors = ['red','green','blue','pink'];

let htmlContent = colors.reduce((output, item)=> {

    let card = `<div class="card m-2 text-white p-2" style="background-color:${item};"> ${item} </div>`;

    return output + card; //"<div>... <div>... <div>...."
}, '');

console.log('htmlContent',htmlContent);

document.querySelector('#card-list').innerHTML = htmlContent;


let tongTien = arrProduct.reduce((tien,prod) => {
    tien += prod.price;
    return tien;
},0);

console.log('tien',tongTien);

let htmlCard = arrProduct.reduce((html,item) => {

    return html + `
        <div class="col-2 mt-2">
            <div class="card">
                <img src="https://i.pravatar.cc?u=${item.id}" />
                <div class="card-body">
                    <h3>${item.name}</h3>
                    <p>${item.price} $</p>
                </div>
            </div>
        </div>
    `
},'');

document.getElementById('product-card').innerHTML = htmlCard;   



